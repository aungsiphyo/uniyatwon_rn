import { FontAwesome } from "@expo/vector-icons";
import { useState } from "react";
import {
  Alert,
  Image,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

const PRIMARY = "#FFD84D";

const API_URL = "http://10.66.145.187:8080/UniYatWoon_adminPanel/user_create.php";

export default function SignupScreen() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [major, setMajor] = useState("");
  const [loading, setLoading] = useState(false);

  const submitAlert = async () => {
    if (!name || !email || !password || !major) {
      Alert.alert("Error", "Please fill all fields");
      return;
    }

    setLoading(true);

    try {
      const res = await fetch(API_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          Username: name,
          Email: email,
          Password: password,
          Major: major,
          Year: "",
          Phone: "",
        }),
      });

      const text = await res.text();
console.log("RAW RESPONSE:", text);
Alert.alert("Alert", text);
return;


    } catch (err) {
      Alert.alert("Network Error", err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      {/* Logo */}
      <View style={styles.logoContainer}>
        <Image
          source={require("../../assets/images/logo1.png")}
          style={styles.logo}
        />
      </View>

      {/* Title */}
      <Text style={styles.title}>Create an Account</Text>
      <Text style={styles.subtitle}>Sign up and meet the community</Text>

      {/* Full Name */}
      <Text style={styles.label}>        Full Name</Text>
      <TextInput
        placeholder="Your name"
        style={styles.input}
        value={name}
        onChangeText={setName}
      />

      {/* Email */}
      <Text style={styles.label}>        Email</Text>
      <TextInput
        placeholder="example@gmail.com"
        style={styles.input}
        keyboardType="email-address"
        autoCapitalize="none"
        value={email}
        onChangeText={setEmail}
      />

      {/* Password */}
      <Text style={styles.label}>        Password</Text>
      <TextInput
        placeholder="********"
        style={styles.input}
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />

      {/* School & Major */}
      <Text style={styles.label}>        School and Major</Text>
      <TextInput
        placeholder="Thanlyin Technology University - IT"
        style={styles.input}
        value={major}
        onChangeText={setMajor}
      />

      {/* Submit Button */}
      <TouchableOpacity
        style={styles.submitButton}
        onPress={submitAlert}
        disabled={loading}
      >
        <Text style={styles.submitText}>
          {loading ? "Submitting..." : "Submit"}
        </Text>
      </TouchableOpacity>

      {/* Social Buttons */}
      <View style={styles.socialRow}>
        <TouchableOpacity style={styles.socialButton}>
          <FontAwesome name="apple" size={17} color="#000" />
          <Text style={styles.socialText}> Apple</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.socialButton}>
          <FontAwesome name="google" size={17} color="#DB4437" />
          <Text style={styles.socialText}> Google</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

/* Styles (UNCHANGED) */
const styles = StyleSheet.create({
  container: {
    padding: 24,
    backgroundColor: "#fff",
    flexGrow: 1,
  },
  logoContainer: {
    alignItems: "center",
    marginTop: 30,
    marginBottom: 20,
  },
  logo: {
    width: 240,
    height: 120,
  },
  title: {
    fontSize: 30,
    fontWeight: "700",
    textAlign: "center",
    marginBottom: 6,
  },
  subtitle: {
    fontSize: 14,
    color: "#000000ff",
    textAlign: "center",
    marginBottom: 30,
  },
  label: {
    fontSize: 13,
    color: "#888",
    marginBottom: 6,
    marginTop: 12,
  },
  input: {
    borderWidth: 1.5,
    borderColor: PRIMARY,
    borderRadius: 30,
    paddingHorizontal: 20,
    paddingVertical: 12,
    fontSize: 14,
  },
  submitButton: {
    backgroundColor: PRIMARY,
    borderRadius: 30,
    paddingVertical: 14,
    alignItems: "center",
    marginTop: 25,
    marginBottom: 20,
  },
  submitText: {
    fontSize: 16,
    fontWeight: "600",
  },
  socialRow: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  socialButton: {
    flex: 1,
    flexDirection: "row",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: PRIMARY,
    borderRadius: 30,
    paddingVertical: 12,
    marginHorizontal: 6,
  },
  socialText: {
    fontSize: 14,
    fontWeight: "500",
  },
});
