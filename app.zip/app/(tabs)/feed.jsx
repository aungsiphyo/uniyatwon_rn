import { Feather, FontAwesome, Ionicons } from "@expo/vector-icons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Video } from "expo-av";
import { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Animated,
  Dimensions,
  FlatList,
  Image,
  Modal,
  ScrollView,
  SectionList,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View
} from "react-native";

import endpoints from "../../endpoints/endpoints";

const PRIMARY = "#FFD84D";
const { width, height } = Dimensions.get("window");

const POST_TABS = [
  { key: "normal", label: "Posts" },
  { key: "lost_found", label: "Lost & Found" },
  { key: "announcement", label: "Announcements" },
];

export default function Feed() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentUsername, setCurrentUsername] = useState(null);
  const [activeTab, setActiveTab] = useState("normal");

  // Fetch posts whenever activeTab changes
  useEffect(() => {
    const loadPosts = async () => {
      setLoading(true);
      setPosts([]); // Clear previous data
      try {
        const savedUsername = await AsyncStorage.getItem("username");
        setCurrentUsername(savedUsername);

        const res = await fetch(`${endpoints.fetchposts}?type=${activeTab}`, {
          credentials: "include",
          headers: {
            "X-Username": savedUsername || "",
            Accept: "application/json",
          },
        });

        const data = await res.json();
        const fixed = Array.isArray(data)
          ? data.map((p) => ({
              ...p,
              media: Array.isArray(p.media)
                ? p.media
                : Array.isArray(p.Media)
                ? p.Media
                : [],
            }))
          : [];
        setPosts(fixed);
      } catch (err) {
        console.error("Fetch error:", err);
        setPosts([]);
      } finally {
        setLoading(false);
      }
    };

    loadPosts();
  }, [activeTab]);



  const renderStories = () => (
    <FlatList
      horizontal
      data={STORIES}
      keyExtractor={(i) => i.name}
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={{ paddingLeft: 16, paddingVertical: 8 }}
      renderItem={({ item }) => (
        <View style={styles.storyItem}>
          <View style={styles.storyAvatarWrapper}>
            {item.add ? (
              <View style={styles.addCircle}>
                <Feather name="plus" size={16} color="#fff" />
              </View>
            ) : (
              <Image source={item.avatar} style={styles.storyAvatar} />
            )}
          </View>
          <Text style={styles.storyName}>{item.name}</Text>
        </View>
      )}
    />
  );

  const renderTabs = () => (
    <View style={styles.tabs}> 
      {/* Added bg color to prevent transparency when sticky */}
      {POST_TABS.map((tab) => (
        <TouchableOpacity
          key={tab.key}
          style={[styles.tabButton, activeTab === tab.key && styles.activeTab]}
          onPress={() => setActiveTab(tab.key)}
        >
          <Text style={styles.tabText}>{tab.label}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );

  return (
    <View style={styles.root}>
      {/* ================= HEADER ================= */}
      <View style={styles.header}>
        <View style={styles.brandRow}>
          <Text style={styles.brandIcon}>Ü</Text>
          <View>
            <Text style={styles.brandText}>Uni Yatwoon</Text>
            <Text style={styles.brandSub}>University Social Platform</Text>
          </View>
        </View>

        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <Feather name="bell" size={20} style={{ marginRight: 16 }} />
          <Feather name="settings" size={20} />
        </View>
      </View>

      {/* ================= FEED (SectionList for Sticky Tabs) ================= */}
      <SectionList
        sections={[{ data: posts }]}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={{ paddingBottom: 100 }}
        ListHeaderComponent={renderStories}
        renderSectionHeader={renderTabs}
        stickySectionHeadersEnabled={true}
        ListFooterComponent={
          loading ? <ActivityIndicator size="large" color={PRIMARY} style={{ marginTop: 20 }} /> : null
        }
        renderItem={({ item }) => <Post item={item} currentUsername={currentUsername} />}
      />
    </View>
  );
}

/* ================= COMMENT COMPONENT ================= */
function CommentItem({ item }) {
  const [liked, setLiked] = useState(false);

  return (
    <View style={[styles.commentRow, item.isReply && styles.replyRow]}>
      <Image source={item.avatar} style={styles.commentAvatar} />
      <View style={styles.commentContent}>
        <View style={styles.commentHeaderRow}>
          <Text style={styles.commentName}>{item.name}</Text>
          <Text style={styles.commentTime}>{item.time}</Text>
        </View>
        <Text style={styles.commentText}>{item.text}</Text>
        <TouchableOpacity>
          <Text style={styles.replyText}>Reply</Text>
        </TouchableOpacity>
      </View>
      <TouchableOpacity onPress={() => setLiked(!liked)} style={styles.commentLike}>
        <Ionicons name={liked ? "heart" : "heart-outline"} size={16} color={liked ? "#D64545" : "#000"} />
      </TouchableOpacity>
    </View>
  );
}

/* ================= POST COMPONENT ================= */
function Post({ item, currentUsername }) {
  const initialLikeCount =
    item.like_count ?? item.likes ?? item.Likes ?? item.Like_count ?? 0;
  const initialIsLiked =
    item.is_liked === true || item.is_liked === 1 || item.is_liked === "1";
  const initialIsSaved =
    item.is_saved === true || item.is_saved === 1 || item.is_saved === "1";

  const [liked, setLiked] = useState(initialIsLiked);
  const [likeCount, setLikeCount] = useState(initialLikeCount);
  const [saved, setSaved] = useState(initialIsSaved);
  const [commentVisible, setCommentVisible] = useState(false);
  const [viewerVisible, setViewerVisible] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);

  const scaleLike = useRef(new Animated.Value(1)).current;
  const scaleComment = useRef(new Animated.Value(1)).current;
  const scaleSave = useRef(new Animated.Value(1)).current;
  const flatListRef = useRef();

  const bounce = (v) => {
    Animated.sequence([
      Animated.timing(v, { toValue: 1.3, duration: 120, useNativeDriver: true }),
      Animated.timing(v, { toValue: 1, duration: 120, useNativeDriver: true }),
    ]).start();
  };

  const media = Array.isArray(item.media) ? item.media : [];

  return (
    <View style={styles.post}>
      {/* POST HEADER */}
      <View style={styles.postHeader}>
        <Image
          source={{ uri: encodeURI(endpoints.baseURL + (item.Profile_photo || "").trim()) }}
          style={styles.postAvatar}
        />
        <View style={{ flex: 1 }}>
          <Text style={styles.postName}>{item.Username}</Text>
          <Text style={styles.postTime}>{item.Created_at}</Text>
        </View>
        <Feather name="more-vertical" size={18} />
      </View>

      {/* POST DESCRIPTION */}
      <Text style={styles.postText}>{item.Description}</Text>

      {/* MEDIA THUMBNAILS */}
      {media.length > 0 && (
        <View style={{ marginTop: 12 }}>
          {media.length === 1 ? (
            // SINGLE MEDIA
            (() => {
              const m = media[0];
              const url = encodeURI(
                endpoints.baseURL.replace(/\/$/, "") + "/" + m.Media_url.replace(/^\//, "")
              );
              return (
                <TouchableOpacity
                  onPress={() => {
                    setActiveIndex(0);
                    setViewerVisible(true);
                  }}
                  style={{ width: "100%" }}
                >
                  {m.Media_type === "video" ? (
                    <Video source={{ uri: url }} style={styles.postImage} />
                  ) : (
                    <Image source={{ uri: url }} style={styles.postImage} />
                  )}
                </TouchableOpacity>
              );
            })()
          ) : (
            // MULTIPLE MEDIA (Horizontal Scroll / Thread style)
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              {media.map((m, i) => {
                const url = encodeURI(
                  endpoints.baseURL.replace(/\/$/, "") + "/" + m.Media_url.replace(/^\//, "")
                );
                return (
                  <TouchableOpacity
                    key={i}
                    onPress={() => {
                      setActiveIndex(i);
                      setViewerVisible(true);
                      setTimeout(() => {
                        flatListRef.current?.scrollToIndex({ index: i, animated: false });
                      }, 50);
                    }}
                    style={styles.carouselItem}
                  >
                    {m.Media_type === "video" ? (
                      <Video source={{ uri: url }} style={styles.postImage} />
                    ) : (
                      <Image source={{ uri: url }} style={styles.postImage} />
                    )}
                  </TouchableOpacity>
                );
              })}
            </ScrollView>
          )}
        </View>
      )}

      {/* POST ACTIONS */}
      <View style={styles.postActions}>
        {/* LIKE */}
        <TouchableOpacity
          onPress={async () => {
            const prev = liked;
            const prevCount = likeCount;
            setLiked(!prev);
            setLikeCount(prev ? prevCount - 1 : prevCount + 1);
            bounce(scaleLike);

            try {
              const fd = new FormData();
              fd.append("post_id", item.id);
              const res = await fetch(endpoints.likePost, {
                method: "POST",
                body: fd,
                credentials: "include",
                headers: { "X-Username": currentUsername || "" },
              });
              const data = await res.json();
              if (!data?.success) {
                setLiked(prev);
                setLikeCount(prevCount);
              }
            } catch {
              setLiked(prev);
              setLikeCount(prevCount);
            }
          }}
        >
          <Animated.View style={[styles.actionRow, { transform: [{ scale: scaleLike }] }]}>
            <FontAwesome
              name={liked ? "heart" : "heart-o"}
              size={18}
              color={liked ? "#D64545" : "#444"}
            />
            {likeCount > 0 && <Text style={styles.actionText}>{likeCount}</Text>}
          </Animated.View>
        </TouchableOpacity>

        {/* COMMENT */}
        <TouchableOpacity onPress={() => setCommentVisible(true)}>
          <Animated.View style={[styles.actionRow, { transform: [{ scale: scaleComment }] }]}>
            <FontAwesome name="comment-o" size={18} />
            <Text style={styles.actionText}>Comment</Text>
          </Animated.View>
        </TouchableOpacity>

        {/* SAVE */}
        <TouchableOpacity
          onPress={async () => {
            const prev = saved;
            setSaved(!prev);
            bounce(scaleSave);

            try {
              const fd = new FormData();
              fd.append("post_id", item.id);
              const res = await fetch(endpoints.savePost, {
                method: "POST",
                body: fd,
                credentials: "include",
                headers: { "X-Username": currentUsername || "" },
              });
              const data = await res.json();
              if (!data?.success) setSaved(prev);
            } catch {
              setSaved(prev);
            }
          }}
        >
          <Animated.View style={{ transform: [{ scale: scaleSave }] }}>
            <FontAwesome
              name={saved ? "bookmark" : "bookmark-o"}
              size={18}
              color={saved ? PRIMARY : "#444"}
            />
          </Animated.View>
        </TouchableOpacity>
      </View>

      {/* COMMENT MODAL */}
      <Modal visible={commentVisible} animationType="slide">
        <View style={styles.commentBox}>
          <View style={styles.commentHeader}>
            <Text style={styles.commentTitle}>Comments</Text>
            <TouchableOpacity onPress={() => setCommentVisible(false)}>
              <Ionicons name="close" size={24} color="#000" />
            </TouchableOpacity>
          </View>

          <FlatList
            data={COMMENTS}
            keyExtractor={(item) => item.id}
            showsVerticalScrollIndicator={false}
            renderItem={({ item }) => <CommentItem item={item} />}
            contentContainerStyle={{ paddingBottom: 20 }}
          />

          <View style={styles.inputWrapper}>
            <Image
              source={{ uri: "https://i.pravatar.cc/150?img=11" }} // Current user
              style={styles.inputAvatar}
            />
            <TextInput placeholder="Add a comment..." style={styles.commentInput} />
          </View>
        </View>
      </Modal>

      {/* MEDIA SWIPE MODAL */}
      <Modal visible={viewerVisible} animationType="fade" transparent={true}>
        <View style={viewerStyles.modalBackground}>
          <FlatList
            ref={flatListRef}
            data={media}
            horizontal
            pagingEnabled
            keyExtractor={(_, index) => String(index)}
            showsHorizontalScrollIndicator={false}
            initialScrollIndex={activeIndex}
            onMomentumScrollEnd={(ev) => {
              const index = Math.round(ev.nativeEvent.contentOffset.x / width);
              setActiveIndex(index);
            }}
            renderItem={({ item: m }) => {
              const url = encodeURI(
                endpoints.baseURL.replace(/\/$/, "") + "/" + m.Media_url.replace(/^\//, "")
              );
              return (
                <View style={{ width, justifyContent: "center", alignItems: "center" }}>
                  {m.Media_type === "video" ? (
                    <Video
                      source={{ uri: url }}
                      style={{ width: width * 0.9, height: height * 0.6, borderRadius: 12 }}
                      resizeMode="contain"
                      shouldPlay
                      useNativeControls
                    />
                  ) : (
                    <Image
                      source={{ uri: url }}
                      style={{ width: width * 0.9, height: height * 0.6, borderRadius: 12 }}
                      resizeMode="contain"
                    />
                  )}
                </View>
              );
            }}
          />
          <TouchableOpacity
            style={viewerStyles.closeButton}
            onPress={() => setViewerVisible(false)}
          >
            <Text style={{ color: "#fff", fontSize: 16 }}>Close</Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </View>
  );
}

/* ================= DATA ================= */
const STORIES = [
  { name: "You", add: true },
  { name: "Htet", avatar: require("../../assets/images/3.jpg") },
  { name: "Aung", avatar: require("../../assets/images/4.jpg") },
  { name: "Nay", avatar: require("../../assets/images/5.jpg") },
  { name: "Si", avatar: require("../../assets/images/6.png") },
];

const COMMENTS = [
  {
    id: "1",
    name: "Htet Linn Htoo",
    time: "18 min.",
    text: "write something...",
    avatar: require("../../assets/images/3.jpg"), // Using existing assets or remote
    isReply: false,
  },
  {
    id: "2",
    name: "Aung Si Phyo",
    time: "18 min.",
    text: "write something...",
    avatar: require("../../assets/images/4.jpg"),
    isReply: true,
  },
];

/* ================= STYLES ================= */
const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: "#fff" },
  header: {
    paddingTop: 50,
    paddingBottom: 12,
    paddingHorizontal: 16,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  brandRow: { flexDirection: "row", alignItems: "center" },
  brandIcon: { fontSize: 34, color: PRIMARY, marginRight: 8 },
  brandText: { fontWeight: "700", fontSize: 16 },
  brandSub: { fontSize: 11, color: "#888" },

  tabs: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "center",
    paddingTop: 0,
    paddingBottom: 6,
    backgroundColor: "#fff",
  },
  tabButton: {
    paddingVertical: 6,
    paddingHorizontal: 14,
    borderRadius: 20,
    backgroundColor: "#eee",
    marginRight: 8,
  },
  activeTab: { backgroundColor: PRIMARY },
  tabText: { fontSize: 13, fontWeight: "600" },

  storyItem: { alignItems: "center", marginRight: 14 },
  storyAvatarWrapper: {
    width: 56,
    height: 56,
    borderRadius: 28,
    borderWidth: 2,
    borderColor: PRIMARY,
    justifyContent: "center",
    alignItems: "center",
  },
  storyAvatar: { width: 46, height: 46, borderRadius: 23 },
  addCircle: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: PRIMARY,
    justifyContent: "center",
    alignItems: "center",
  },
  storyName: { marginTop: 6, fontSize: 12 },

  post: { paddingHorizontal: 16, marginBottom: 24 },
  postHeader: { flexDirection: "row", alignItems: "center", marginTop: 12 },
  postAvatar: { width: 40, height: 40, borderRadius: 20, marginRight: 10 },
  postName: { fontWeight: "600" },
  postTime: { fontSize: 11, color: "#888" },
  postText: { marginTop: 10 },

  // Updated / Removed old grid styles for media
  // mediaContainer: { flexDirection: "row", flexWrap: "wrap", marginTop: 12 },
  // mediaItem: { width: "48%", marginRight: "2%", marginBottom: 8 },
  
  carouselItem: {
    width: width * 0.65, // Approx 2/3 of screen width
    marginRight: 10,
    borderRadius: 12,
    overflow: "hidden",
  },
  postImage: { height: 200, width: "100%", borderRadius: 12, backgroundColor: '#f0f0f0' }, // Reduced height

  postActions: { flexDirection: "row", justifyContent: "space-between", marginTop: 12 },
  actionRow: { flexDirection: "row", alignItems: "center" },
  actionText: { marginLeft: 6, fontSize: 14 },

  commentBox: { flex: 1, backgroundColor: "#fff", paddingTop: 50 },
  commentHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 12,
    marginBottom: 24,
  },
  commentTitle: { fontSize: 16, fontWeight: "700" },
  
  commentRow: {
    flexDirection: "row",
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  replyRow: {
    marginLeft: 50, // Indent for reply
  },
  commentAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 10,
  },
  commentContent: {
    flex: 1,
  },
  commentHeaderRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 2,
  },
  commentName: {
    fontWeight: "600",
    fontSize: 14,
    marginRight: 6,
  },
  commentTime: {
    fontSize: 12,
    color: "#888",
  },
  commentText: {
    fontSize: 14,
    color: "#000",
    marginBottom: 4,
  },
  replyText: {
    fontSize: 12,
    color: "#666",
    fontWeight: "500",
  },
  commentLike: {
    paddingLeft: 10,
    paddingTop: 5,
  },

  inputWrapper: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderTopWidth: 1,
    borderTopColor: "#eee",
  },
  inputAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    marginRight: 10,
  },
  commentInput: {
    flex: 1,
    height: 40,
    borderRadius: 20,
    backgroundColor: "#f0f2f5",
    paddingHorizontal: 15,
  },
});

const viewerStyles = StyleSheet.create({
  modalBackground: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.95)",
    justifyContent: "center",
    alignItems: "center",
  },
  closeButton: {
    position: "absolute",
    top: 50,
    right: 20,
    padding: 10,
    backgroundColor: "rgba(0,0,0,0.6)",
    borderRadius: 20,
  },
});
