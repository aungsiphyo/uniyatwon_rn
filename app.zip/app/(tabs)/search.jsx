import { Ionicons } from "@expo/vector-icons";
import { useState } from "react";
import {
    FlatList,
    Image,
    SafeAreaView,
    StatusBar,
    StyleSheet,
    Text,
    TextInput,
    TouchableOpacity,
    View
} from "react-native";

// Mock Data
const RECENT_SEARCHES = [
  { id: "1", text: "UniYatWoon Group", type: "group" },
  { id: "2", text: "React Native Developers", type: "group" },
  { id: "3", text: "John Doe", type: "user", avatar: "https://i.pravatar.cc/100?img=3" },
  { id: "4", text: "New University Updates", type: "page" },
];

const SUGGESTED_FOR_YOU = [
  { id: "5", text: "Campus Events 2024", type: "event", avatar: "https://i.pravatar.cc/100?img=5" },
  { id: "6", text: "Study Partners", type: "group", avatar: "https://i.pravatar.cc/100?img=8" },
];

export default function SearchScreen() {
  const [query, setQuery] = useState("");
  const [isFocused, setIsFocused] = useState(false);

  const renderItem = ({ item }) => (
    <TouchableOpacity style={styles.itemRow}>
      <View style={styles.iconContainer}>
        {item.avatar ? (
          <Image source={{ uri: item.avatar }} style={styles.avatar} />
        ) : (
            <Ionicons
                name={item.type === "group" ? "people-circle-outline" : "search-outline"}
                size={24}
                color="#666"
            />
        )}
      </View>
      <View style={styles.itemTextContainer}>
        <Text style={styles.itemTitle}>{item.text}</Text>
        <Text style={styles.itemSubtitle}>{item.type}</Text>
      </View>
      <TouchableOpacity>
        <Ionicons name="close" size={20} color="#999" />
      </TouchableOpacity>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.searchBar}>
          <Ionicons name="search" size={20} color="#666" style={{ marginRight: 8 }} />
          <TextInput
            style={styles.input}
            placeholder="Search UniYatWoon"
            value={query}
            onChangeText={setQuery}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
          />
        </View>
      </View>

      <View style={styles.content}>
        {/* Recent Searches Header */}
        <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Recent</Text>
            <TouchableOpacity>
                <Text style={styles.seeAllText}>See all</Text>
            </TouchableOpacity>
        </View>

        <FlatList
          data={[...RECENT_SEARCHES, ...SUGGESTED_FOR_YOU]}
          keyExtractor={(item) => item.id}
          renderItem={renderItem}
          showsVerticalScrollIndicator={false}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    paddingTop: StatusBar.currentHeight || 40,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#eee",
  },
  searchBar: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#f0f2f5",
    borderRadius: 20,
    paddingHorizontal: 12,
    height: 40,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: "#000",
  },
  content: {
    flex: 1,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "bold",
  },
  seeAllText: {
    color: "#1877f2",
    fontSize: 14,
  },
  itemRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 10,
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "#f0f2f5", // Fallback if no avatar
    justifyContent: "center",
    alignItems: "center",
    marginRight: 12,
    overflow: "hidden",
  },
  avatar: {
    width: 40,
    height: 40,
  },
  itemTextContainer: {
    flex: 1,
  },
  itemTitle: {
    fontSize: 15,
    fontWeight: "500",
  },
  itemSubtitle: {
    fontSize: 12,
    color: "#666",
    textTransform: 'capitalize'
  },
});