import { Ionicons } from "@expo/vector-icons";
import { useFocusEffect } from "@react-navigation/native";
import { useCallback, useState } from "react";
import {
  FlatList,
  Image,
  RefreshControl,
  StyleSheet, Text, TouchableOpacity, View
} from "react-native";

const API_URL = "http://localhost:8080/UniYatWoon_adminPanel/profile.php";

import { useAuth } from "../../context/AuthContext";

export default function Feed() {
  const { signOut } = useAuth();
  const [profile, setProfile] = useState(null);
    const [refreshing, setRefreshing] = useState(false);
  
    const fetchProfile = async () => {
      try {
        const res = await fetch(API_URL, {
          method: "GET",
          credentials: "include",
        });
        const data = await res.json();
        if (!data.success) return setProfile(null);
        setProfile(data);
      } catch (err) {
        console.log(err);
      }
    };
  
    useFocusEffect(
      useCallback(() => {
        fetchProfile();
      }, [])
    );
  
    const onRefresh = async () => {
      setRefreshing(true);
      await fetchProfile();
      setRefreshing(false);
    };
  
    if (!profile) {
      return (
        <View style={styles.center}>
          <Text>Loading profile...</Text>
        </View>
      );
    }
  return (
    <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
      <FlatList
          data={profile.posts}
          keyExtractor={(item) => item.id.toString()}
          numColumns={3}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
          ListHeaderComponent={
            <>
              {/* Top Bar */}
              <View style={styles.topBar}>
                <Ionicons name="chevron-back" size={24} />
                <TouchableOpacity style={styles.logoutBtn} onPress={signOut}>
                  <Text style={{ color: "#fff", fontWeight: "600" }}>Log Out</Text>
                </TouchableOpacity>
              </View>
  
              {/* Profile Info */}
              <View style={styles.profileSection}>
                <Image
                  source={{
                    uri:
                      "http://10.248.106.220/UniYatWoon_adminPanel-master/" +
                      profile.posts[0]?.Profile_photo,
                  }}
                  style={styles.avatar}
                />
                <View>
                  <Text style={styles.username}>{profile.username}</Text>
                  <Text style={styles.bio}>CEIT</Text>
                </View>
              </View>
  
              {/* Stats */}
              <View style={styles.statsRow}>
                <Stat label="Following" value="200" />
                <Stat label="Followers" value="1.2k" />
                <Stat label="Posting" value={profile.posts.length} />
              </View>
  
              {/* Edit Button */}
              <TouchableOpacity style={styles.editBtn}>
                <Text style={styles.editText}>Edit Profile</Text>
              </TouchableOpacity>
  
              {/* Tabs */}
              <View style={styles.tabs}>
                <Ionicons name="grid-outline" size={22} />
                <Ionicons name="play-circle-outline" size={22} />
                <Ionicons name="document-text-outline" size={22} />
              </View>
            </>
          }
          renderItem={({ item }) => (
            <Image
              source={{
                uri:
                  "http://10.248.106.220/UniYatWoon_adminPanel-master/" +
                  item.media?.[0]?.Media_url,
              }}
              style={styles.gridImage}
            />
          )}
        />
  
        {/* Floating Add Button */}
        <TouchableOpacity style={styles.fab}>
          <Ionicons name="add" size={28} color="#fff" />
        </TouchableOpacity>
  
        {/* Bottom Tab Bar */}
        
    </View>
  );
}

const Stat = ({ label, value }) => (
  <View style={styles.statItem}>
    <Text style={styles.statValue}>{value}</Text>
    <Text style={styles.statLabel}>{label}</Text>
  </View>
);

const styles = StyleSheet.create({
  center: { flex: 1, justifyContent: "center", alignItems: "center" },

  topBar: {
    flexDirection: "row",
    justifyContent: "space-between",
    padding: 12,
    alignItems: "center",
  },

  logoutBtn: {
    backgroundColor: "#FFC107",
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: 8,
  },

  profileSection: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    marginTop: 10,
  },

  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginRight: 12,
  },

  username: { fontSize: 18, fontWeight: "700" },
  bio: { color: "#666", marginTop: 2 },

  statsRow: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginVertical: 16,
  },

  statItem: { alignItems: "center" },
  statValue: { fontSize: 18, fontWeight: "700" },
  statLabel: { fontSize: 12, color: "#666" },

  editBtn: {
    backgroundColor: "#FFC107",
    marginHorizontal: 16,
    borderRadius: 10,
    paddingVertical: 10,
    alignItems: "center",
  },

  editText: { fontWeight: "700", color: "#fff" },

  tabs: {
    flexDirection: "row",
    justifyContent: "space-around",
    paddingVertical: 12,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: "#eee",
    marginTop: 10,
  },

  gridImage: {
    width: "33.33%",
    aspectRatio: 1,
    borderWidth: 1,
    borderColor: "#fff",
  },

  fab: {
    position: "absolute",
    bottom: 70,
    alignSelf: "center",
    backgroundColor: "#FFC107",
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: "center",
    alignItems: "center",
    elevation: 6,
  },

 
});
