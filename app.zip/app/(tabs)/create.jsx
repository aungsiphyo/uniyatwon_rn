import { FontAwesome } from "@expo/vector-icons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as ImagePicker from "expo-image-picker";
import { useRouter } from "expo-router";
import { useEffect, useState } from "react";
import {
  Alert,
  Image,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

const API_URL = "http://localhost:8080/UniYatWoon_adminPanel/addposts.php";

export default function Create() {
  const router = useRouter();
  const [description, setDescription] = useState("");
  const [media, setMedia] = useState([]);
  const [loading, setLoading] = useState(false);

  const [username, setUsername] = useState(null);
  const [userUUID, setUserUUID] = useState(null);

  // ===== LOAD USER =====
  useEffect(() => {
    const loadUser = async () => {
      let u, id;
      if (Platform.OS === "web") {
        u = localStorage.getItem("Username");
        id = localStorage.getItem("user_uuid");
      } else {
        u = await AsyncStorage.getItem("Username");
        id = await AsyncStorage.getItem("user_uuid");
      }

      if (!u || !id) {
        Alert.alert("Login required", "Please login again");
        return;
      }

      setUsername(u);
      setUserUUID(id);
    };
    loadUser();
  }, []);

  // ===== PICK MEDIA =====
  const pickMedia = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsMultipleSelection: true,
      quality: 1,
    });

    if (!result.canceled) {
      setMedia((prev) => [...prev, ...result.assets]);
    }
  };

  // ===== REMOVE MEDIA =====
  const removeMedia = (index) => {
    setMedia((prev) => prev.filter((_, i) => i !== index));
  };

  // ===== HANDLE POST =====
  const handlePost = async () => {
    if (!username || !userUUID)
      return Alert.alert("Error", "Not logged in");

    if (!description && media.length === 0)
      return Alert.alert("Error", "Write something or add media");

    const formData = new FormData();
    formData.append("Description", description);
    formData.append("Username", username);
    formData.append("user_uuid", userUUID);

    media.forEach((file, i) => {
      const ext = file.uri.split(".").pop();
      formData.append("media[]", {
        uri: file.uri,
        name: `upload_${Date.now()}_${i}.${ext}`,
        type: file.type === "video" ? "video/mp4" : `image/${ext}`,
      });
    });

    try {
      setLoading(true);
      const res = await fetch(API_URL, {
        method: "POST",
        body: formData,
      });

      const data = await res.json();

      if (data.success) {
        Alert.alert("Success", "Post uploaded", [
          {
            text: "OK",
            onPress: () => {
              setDescription("");
              setMedia([]);
              router.replace("/(tabs)/feed"); // 👈 go to New Feed
            },
          },
        ]);
      } else {
        Alert.alert("Error", data.message);
      }
    } catch {
      Alert.alert("Network Error", "Upload failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>

      {/* User */}
      <View style={styles.userRow}>
        <Image
          source={{ uri: "https://i.pravatar.cc/150" }}
          style={styles.avatar}
        />
        <Text style={styles.username}>{username || "Loading..."}</Text>
      </View>

      {/* Text */}
      <TextInput
        placeholder="Write a message...?"
        multiline
        value={description}
        onChangeText={setDescription}
        style={styles.input}
      />

      {/* Preview */}
      <ScrollView horizontal style={styles.previewContainer}>
        {media.map((file, index) => (
          <View key={index} style={styles.previewWrapper}>
            <Image source={{ uri: file.uri }} style={styles.preview} />
            <TouchableOpacity
              style={styles.removeBtn}
              onPress={() => removeMedia(index)}
            >
              <Text style={{ color: "white", fontWeight: "bold" }}>X</Text>
            </TouchableOpacity>
          </View>
        ))}
      </ScrollView>

      {/* Bottom */}
      <View style={styles.bottom}>
        <TouchableOpacity onPress={pickMedia} style={styles.mediaBtn}>
          <FontAwesome name="image" size={22} />
        </TouchableOpacity>

        <TouchableOpacity
          onPress={handlePost}
          style={styles.postBtn}
          disabled={loading}
        >
          <Text style={styles.postText}>
            {loading ? "Posting..." : "Post"}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

/* ================= STYLES ================= */
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff", padding: 16 },

  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 20,
  },

  headerTitle: { fontSize: 18, fontWeight: "600" },

  userRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 40,
    marginBottom: 12,
  },

  avatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    marginRight: 10,
  },

  username: { fontSize: 14, fontWeight: "500" },

  input: {
    fontSize: 16,
    minHeight: 120,
    textAlignVertical: "top",
  },

  previewContainer: {
    flexDirection: "row",
    marginVertical: 10,
  },

  previewWrapper: {
    position: "relative",
    marginRight: 10,
  },

  preview: {
    width: 120,
    height: 120,
    borderRadius: 10,
  },

  removeBtn: {
    position: "absolute",
    top: 4,
    right: 4,
    backgroundColor: "red",
    width: 24,
    height: 24,
    borderRadius: 12,
    justifyContent: "center",
    alignItems: "center",
  },

  bottom: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: "auto",
  },

  mediaBtn: { padding: 10 },

  postBtn: {
    marginLeft: "auto",
    backgroundColor: "#FFD84D",
    paddingHorizontal: 24,
    paddingVertical: 10,
    borderRadius: 20,
  },

  postText: { fontWeight: "600" },
});
