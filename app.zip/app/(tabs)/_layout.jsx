import { Ionicons } from "@expo/vector-icons";
import { Tabs } from "expo-router";

export default function TabsLayout() {
  return (
    <Tabs
      initialRouteName="feed" // Home loads first
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color, size, focused }) => {
          let iconName;

          // Map route names to Ionicons names
          if (route.name === "feed") {
            iconName = focused ? "home" : "home-outline";
          } else if (route.name === "search") {
            iconName = focused ? "search" : "search-outline";
          } else if (route.name === "create") {
            iconName = focused ? "add" : "add-outline";
          }else if (route.name === "message") {
            iconName = focused ? "chatbubble" : "chatbubble-outline";
          } else if (route.name === "profile") {
            iconName = focused ? "person" : "person-outline";
          }

          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: "#FFD84D",
        tabBarInactiveTintColor: "gray",
        headerShown: false, // hide header for tabs
      })}
    >
      <Tabs.Screen name="feed" options={{ title: "New Feed" }} />
      <Tabs.Screen name="search" options={{ title: "Search" }} />
      <Tabs.Screen name="create" options={{ title: "Create Post" }} />
      <Tabs.Screen name="message" options={{ title: "Chat" }} />
      <Tabs.Screen name="profile" options={{ title: "My Profile" }} />
    </Tabs>
  );
}
