import { Stack, useRootNavigationState, useRouter, useSegments } from "expo-router";
import { useEffect, useState } from "react";
import { ActivityIndicator, View } from "react-native";
import { AuthProvider, useAuth } from "../context/AuthContext";

function StackLayout() {
  const { userSession, isLoading } = useAuth();
  const segments = useSegments();
  const router = useRouter();
  const navigationState = useRootNavigationState();

  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  useEffect(() => {
    if (isLoading || !isMounted || !navigationState?.key) return;

    const inAuthGroup = segments[0] === "auth";
    
    console.log("RootLayout: Auth check", { 
      userSession: !!userSession, 
      segments: segments, 
      inAuthGroup 
    });

    if (!userSession && !inAuthGroup) {
      // Redirect to the login page if not logged in
      console.log("RootLayout: Redirecting to login");
      router.replace("/auth/login");
    } else if (userSession && inAuthGroup) {
      // Redirect to the home page if already logged in
      console.log("RootLayout: Redirecting to feed");
      router.replace("/(tabs)/feed");
    }
  }, [userSession, segments, isLoading, isMounted, navigationState]);

  if (isLoading || !isMounted || !navigationState?.key) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <ActivityIndicator size="large" color="#FFD84D" />
      </View>
    );
  }

  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      <Stack.Screen name="auth" options={{ headerShown: false }} />
    </Stack>
  );
}

export default function RootLayout() {
  return (
    <AuthProvider>
      <StackLayout />
    </AuthProvider>
  );
}
